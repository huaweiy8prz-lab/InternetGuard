@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed. Open this project in Android Studio, or install Gradle 8.9+ and run gradlew.bat assembleDebug.
exit /b 1
