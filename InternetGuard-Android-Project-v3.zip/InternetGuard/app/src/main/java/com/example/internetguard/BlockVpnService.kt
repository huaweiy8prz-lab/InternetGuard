package com.example.internetguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.app.Service
import android.content.pm.ServiceInfo

/** Local VPN used only to block traffic after the configured limit is reached. */
class BlockVpnService : VpnService() {
    private var tunnel: android.os.ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        startVpn()
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "guard_block"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "مسدودسازی اینترنت", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("کنترل مصرف اینترنت")
            .setContentText("اینترنت به‌دلیل رسیدن به سقف مصرف مسدود شده است")
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(8, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(8, notification)
        }
    }

    private fun startVpn() {
        if (tunnel != null) return
        tunnel = Builder()
            .setSession("InternetGuard - Block")
            .addAddress("10.10.10.2", 32)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            .setBlocking(true)
            .establish()
    }

    private fun stopVpn() {
        tunnel?.close()
        tunnel = null
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    companion object {
        const val ACTION_STOP = "com.example.internetguard.STOP_BLOCK"
    }
}
