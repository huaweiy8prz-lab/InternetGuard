package com.example.internetguard

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.net.TrafficStats
import android.net.VpnService
import android.provider.Settings
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var used: TextView
    private lateinit var limit: EditText
    private lateinit var warning: EditText
    private lateinit var block: CheckBox
    private val prefs by lazy { getSharedPreferences("guard", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi(); if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10) }
    private fun buildUi() {
        val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(40,50,40,30); box.gravity=Gravity.CENTER_HORIZONTAL
        val title=TextView(this); title.text="کنترل مصرف اینترنت"; title.textSize=26f; title.setTextColor(Color.DKGRAY); box.addView(title)
        used=TextView(this); used.textSize=20f; used.gravity=Gravity.CENTER; box.addView(used, LinearLayout.LayoutParams(-1,80))
        limit=EditText(this); limit.hint="سقف مصرف (گیگابایت)"; limit.inputType=2 or 8192; limit.setText(prefs.getFloat("limitGb",5f).toString()); box.addView(limit)
        warning=EditText(this); warning.hint="درصد هشدار (مثلاً 80)"; warning.inputType=2; warning.setText(prefs.getInt("warning",80).toString()); box.addView(warning)
        block=CheckBox(this); block.text="بعد از رسیدن به سقف، اینترنت را قطع کن"; block.isChecked=prefs.getBoolean("blockOnLimit",false); box.addView(block)
        val save=Button(this); save.text="ذخیره و شروع کنترل"; box.addView(save); save.setOnClickListener { saveAndStart() }
        val reset=Button(this); reset.text="شروع دوباره شمارنده"; box.addView(reset); reset.setOnClickListener { prefs.edit().putLong("startMobile", mobileBytes()).putBoolean("limitAlerted",false).apply(); update(); }
        setContentView(box); update(); Handler(mainLooper).postDelayed(object:Runnable{override fun run(){update();Handler(mainLooper).postDelayed(this,2000)}},2000)
    }
    private fun mobileBytes():Long { val rx=TrafficStats.getMobileRxBytes(); val tx=TrafficStats.getMobileTxBytes(); return if(rx==TrafficStats.UNSUPPORTED.toLong() || tx==TrafficStats.UNSUPPORTED.toLong()) 0 else rx+tx }
    private fun update(){ val start=prefs.getLong("startMobile",mobileBytes()); val now=mobileBytes(); val delta=if(now>=start) now-start else now; used.text="مصرف این دوره: ${fmt(delta)}" }
    private fun saveAndStart(){ val gb=limit.text.toString().toFloatOrNull()?:5f; val w=warning.text.toString().toIntOrNull()?:80; prefs.edit().putFloat("limitGb",gb).putInt("warning",w).putBoolean("blockOnLimit",block.isChecked).putLong("startMobile",mobileBytes()).putBoolean("warningAlerted",false).putBoolean("limitAlerted",false).apply(); val i=Intent(this,MonitorService::class.java); if (block.isChecked && VpnService.prepare(this) != null) { startActivityForResult(VpnService.prepare(this), 42) } else { if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i) }; Toast.makeText(this,"کنترل مصرف فعال شد",Toast.LENGTH_SHORT).show() }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val i=Intent(this,MonitorService::class.java)
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
        }
    }

    private fun fmt(b:Long):String { val gb=b/1024.0/1024/1024; return String.format(Locale.US,"%.2f GB",gb) }
}
