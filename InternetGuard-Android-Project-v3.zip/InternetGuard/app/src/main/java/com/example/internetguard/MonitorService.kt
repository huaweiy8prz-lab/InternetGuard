package com.example.internetguard

import android.app.*
import android.content.*
import android.net.TrafficStats
import android.os.*
import android.content.pm.ServiceInfo

class MonitorService: Service(){
 private val handler=Handler(Looper.getMainLooper()); private lateinit var prefs:android.content.SharedPreferences
 override fun onCreate(){super.onCreate(); prefs=getSharedPreferences("guard",0); createChannel(); startAsForeground(); handler.post(check)}
 private fun startAsForeground(){ val n=notification("کنترل مصرف اینترنت فعال است"); if(Build.VERSION.SDK_INT>=29) startForeground(7,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(7,n) }
 private val check=object:Runnable{override fun run(){checkUsage();handler.postDelayed(this,30000)}}
 private fun bytes():Long{val a=TrafficStats.getMobileRxBytes();val b=TrafficStats.getMobileTxBytes();return if(a<0||b<0)0 else a+b}
 private fun checkUsage(){
   val start=prefs.getLong("startMobile",bytes()); val now=bytes(); val used=if(now>=start)now-start else now
   val limit=(prefs.getFloat("limitGb",5f)*1024*1024*1024).toLong(); val warning=limit*prefs.getInt("warning",80)/100
   if(used>=warning&&!prefs.getBoolean("warningAlerted",false)){prefs.edit().putBoolean("warningAlerted",true).apply();notifyUser("هشدار مصرف","به ${prefs.getInt("warning",80)}٪ سقف مصرف رسیدید")}
   if(used>=limit&&!prefs.getBoolean("limitAlerted",false)){prefs.edit().putBoolean("limitAlerted",true).apply();notifyUser("سقف مصرف رسید","مصرف اینترنت از سقف تعیین‌شده عبور کرد"); if(prefs.getBoolean("blockOnLimit",false)) startBlockingVpn()}
 }
 private fun startBlockingVpn(){ val i=Intent(this,BlockVpnService::class.java); if(Build.VERSION.SDK_INT>=26)startForegroundService(i) else startService(i) }
 private fun notifyUser(t:String,m:String){val nm=getSystemService(NotificationManager::class.java);nm.notify((System.currentTimeMillis()%100000).toInt(),notification(m,t))}
 private fun createChannel(){if(Build.VERSION.SDK_INT>=26){getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("guard","کنترل مصرف",NotificationManager.IMPORTANCE_HIGH))}}
 private fun notification(text:String,title:String="کنترل مصرف اینترنت"):Notification{val b=Notification.Builder(this,"guard").setContentTitle(title).setContentText(text).setSmallIcon(android.R.drawable.stat_notify_sync).setOngoing(true);return b.build()}
 override fun onBind(i:Intent?)=null
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy()}
}
